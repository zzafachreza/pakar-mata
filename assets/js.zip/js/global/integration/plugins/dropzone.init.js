Dropzone.autoDiscover = false;
