"use strict";
$.fn.datepicker.defaults.zIndexOffset = 10;